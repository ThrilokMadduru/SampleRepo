package com.directory.search.controller;

import java.io.File;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.directory.search.service.FileSearchService;



@RestController
public class FileSearchController 
{
	protected Logger logger = LoggerFactory.getLogger(FileSearchController.class);
	@Autowired
	FileSearchService fileService;
	
	@Value("${directoryPath}")
	String directoryPath;
	
	
	@GetMapping("/files/{inputWords}")
	public ResponseEntity<String>  getDirectoryFiles(@PathVariable String inputWords)	
	
	{
		logger.info("List of input words:"+inputWords);
		
		ResponseEntity<String> responseValue =null;
		
		Map<String,List<File>> resultMap=fileService.getDirectoryFiles(directoryPath,inputWords);
				
		JSONObject json = new JSONObject(resultMap);
		
		logger.info("Serach Result for words:"+json.toString());		
		
		responseValue = new ResponseEntity<String>(json.toString(),HttpStatus.FOUND);
		
		return responseValue;		
		
	}
	
	
	
}
