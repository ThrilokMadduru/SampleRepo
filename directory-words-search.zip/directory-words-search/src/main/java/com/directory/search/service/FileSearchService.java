package com.directory.search.service;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface FileSearchService
{		
	Map<String,List<File>> getDirectoryFiles(String directoryPath, String fileName);
	
}
