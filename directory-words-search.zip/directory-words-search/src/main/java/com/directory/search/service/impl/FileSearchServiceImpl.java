package com.directory.search.service.impl;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.StringTokenizer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.directory.search.service.FileSearchService;

@Component
public class FileSearchServiceImpl implements FileSearchService{
	
	protected Logger logger = LoggerFactory.getLogger(FileSearchServiceImpl.class);
	
	public  List<File> fileslist = new ArrayList<File>();
	
	public Map<String, List<File>> getDirectoryFiles(String directoryPath,String inputWords) {
		
		logger.info("Configured directoryPath is:->"+directoryPath);
		
		Map<String,List<File>> searchResult=new HashMap<String,List<File>>();	
		StringTokenizer st = new StringTokenizer(inputWords);
		while (st.hasMoreElements()) 
		{
		String name=st.nextElement().toString();
		listFiles(directoryPath,name);		
		List<File> wordResultList = new ArrayList<File>();
		
		for (int i = 0 ; i<fileslist.size();i++)
		{
			wordResultList.add(fileslist.get(i)) ;
		}		
		
		if(fileslist.size()>0)
		searchResult.put(name, wordResultList);
		
		logger.info("searchResult for "+name+" is:-> "+wordResultList);		
		fileslist.clear();
		
		}
		
		return 	searchResult;
		
	}



private  boolean find(File f, String searchString) 
{
    boolean result = false;
    Scanner in = null;
    try 
    {
        in = new Scanner(new FileReader(f));
        while(in.hasNextLine() && !result) 
        {
            result = in.nextLine().indexOf(searchString) >= 0;
        }
    }
    catch(IOException e) 
    {
        e.printStackTrace();      
    }
    finally 
    {
        try 
        { 
        	in.close() ;
        } 
        catch(Exception e) 
        { 
        	logger.error("Error in Reading the file, Format not supported"+e); 
        }  
    }
    return result;
}


private  void listFiles(String path,String filename)
{
		File folder = new File(path);		
		File[] files = folder.listFiles();
		for (File file : files)
		{
			if (file.isFile())
			{	
				
				if(find(file,filename)){
					
				fileslist.add(file);
				
				}
			} 
			else if (file.isDirectory())			
			{
				listFiles(file.getAbsolutePath(),filename);

			}
		}
	}

	
}
